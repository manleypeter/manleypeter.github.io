$(function () {
	// RÈGLE UN PROBLEME CONNU DE CHROME QUI GÈRE MAL UN FONT-SIZE EN REM SUR LE BODY LORSQUE LE FONT-SIZE DU HTML EST EN %
	// A SUPPRIMER LORSQUE LE BUG SERA RÉSOLU PAR GOOGLE.....
	$('body.isolation-bootstrap-3').css('font-size', '1.3rem');

	$('.panel-tiroir').on('hide.bs.collapse', function (event) {
		$( event.target ).prev().addClass("collapsed");
		$( event.target ).prev().find( "a[data-toggle='collapse']" ).addClass("collapsed");
		
		// Tout afficher - Tout masquer
		var elem = $(this);
		var group = elem.parent('.panel-group');
		var elemsNb = group.find('.panel-tiroir a[data-toggle="collapse"]').length;
		var collapsedNb = group.find('.panel-heading.collapsed').length;

		if(collapsedNb == elemsNb) {
			$('.toggle-tiroir li button.tout-masquer', group).addClass('desactive');
		}
		else {
			$('.toggle-tiroir li button.tout-afficher', group).removeClass('desactive');
		}
		// Fin
	});

	$('.panel-tiroir').on('show.bs.collapse', function (event) {
		$( event.target ).prev().removeClass("collapsed");
		$( event.target ).prev().find( "a[data-toggle='collapse']" ).removeClass("collapsed");
		
		// Tout afficher - Tout masquer
		var elem = $(this);
		var group = elem.parent('.panel-group');
		var elemsNb = group.find('.panel-tiroir').length;
		var collapsedNb = group.find('.panel-heading.collapsed').length;

		if(collapsedNb == 0) {
			$('.toggle-tiroir li button.tout-afficher', group).addClass('desactive');
		}
		else {
			$('.toggle-tiroir li button.tout-masquer', group).removeClass('desactive');
		}
		// Fin
	});

	$('.panel-collapse.collapse').each(function() {
		var self = $(this);
		if (!self.hasClass("in")) {
			self.prev().addClass("collapsed");
			self.prev().find( "a[data-toggle='collapse']" ).addClass("collapsed");
		}
	});

	// Tout afficher - Tout masquer
	var toggleBtns = $('.toggle-tiroir li button');
	toggleBtns.on('click', function (e) {
		e.preventDefault();
		var elem = $(this);
		if(!elem.hasClass('desactive')) {
			var action = elem.hasClass('tout-afficher') ? 'show' : 'hide';
			var group = elem.parents('.panel-group');
			if(action == 'show') {
				var selector = $('.panel-collapse:not(.in)', group);
				$('.tout-masquer', group).removeClass('desactive');
				$('.tout-afficher', group).addClass('desactive');
			}
			else if(action == 'hide') {
				var selector = $('.panel-collapse.in');
				$('.tout-masquer', group).addClass('desactive');
				$('.tout-afficher', group).removeClass('desactive');				
			}
			selector.collapse(action);
		}
	});

	// Ajoute la classe ".visited" aux onglets étapes visités
	$('.onglets-etapes').on('show.bs.tab', function (event) {
		$( event.target ).parent().addClass("visited");
	});

	// Ajout automatique du bouton "Fermer" aux lightboxes
	$('.modal').on('show.bs.modal', function(event) {
		var target = $(event.currentTarget);
		var relatedTarget = $(event.relatedTarget);
		
		if(typeof relatedTarget.attr('data-backdrop') == 'undefined') {
			if(typeof relatedTarget.attr('data-help-url') != 'undefined') {
				var url = relatedTarget.attr('data-help-url');
				var width = (typeof relatedTarget.attr('data-help-url-width') != 'undefined' && relatedTarget.attr('data-help-url-width') != '') ? relatedTarget.attr('data-help-url-width') : 300;
				var height = (typeof relatedTarget.attr('data-help-url-height') != 'undefined' && relatedTarget.attr('data-help-url-height') != '') ? relatedTarget.attr('data-help-url-height') : 200;
				$('.modal-header', target).prepend('<span class="separator"></span><button type="button" class="help" onclick=\'openPopup("' + url + '", ' + width + ', ' + height + ');\'><span class="modal-button-span"></span></button>');
			}
			$('.modal-header', target).prepend('<button type="button" class="close" data-dismiss="modal"><span class="modal-button-span"></span></button>');
		}
	});

	$('.modal').on('hidden.bs.modal', function(event) {
		var target = $(event.currentTarget);
		var relatedTarget = $(event.relatedTarget);
		
		if(typeof relatedTarget.attr('data-backdrop') == 'undefined') {
			$('.close, .help, .separator', target).remove();
		}
	});

	$("table.tableau-donnees.auto").altCouleurs();
});

/** Alternance automatique des couleurs des rangées de tableaux
 * */
(function ( $ ) {
	$.fn.altCouleurs = function() {
		var trs = this.find("tbody > tr");
		var listeTrsCourante = [];
		$.map(trs, function(element, index) {
			if (!$(element).hasClass("sous-titre")) {
				listeTrsCourante.push(element);
			} else if (listeTrsCourante.length > 0) {
				$.traiterTrs(listeTrsCourante);
				listeTrsCourante = [];
			}
		});

		$.traiterTrs(listeTrsCourante);

		return this;
	};

	$.traiterTrs = function( listeTrs ) {
		for (var i = 0; i < listeTrs.length; i++) {
			if (i % 2 == 0) {
				$(listeTrs[i]).removeClass("paire");
				$(listeTrs[i]).addClass("impaire");
			} else {
				$(listeTrs[i]).removeClass("impaire");
				$(listeTrs[i]).addClass("paire");
			}
		}
	};
}( jQuery ));


/*
 * Extend les fonctionnalités du popover de bootstrap
 * - Position des flèches: data-arrow
 * - Correctif de performance pour IE
 * -------------------------------------------------- */

$.fn.popover.Constructor.DEFAULTS = $.extend({} , $.fn.tooltip.Constructor.DEFAULTS, {
	placement: 'right',
	trigger: 'click',
	content: '',
	template: '<div class="popover"><div class="arrow"></div><h3 class="popover-title"></h3><button type="button" class="close" data-dismiss="clickover"><span class="popover-button-span"></span></button><div class="popover-content"><div></div></div></div>'
});

var _superPopover = $.fn.popover;

var Popover = function(element, options) {
	_superPopover.Constructor.apply( this, arguments );
};

Popover.prototype = $.extend({}, _superPopover.Constructor.prototype, {
	constructor: Popover,
	_superPopover: function() {
		var args = $.makeArray(arguments);
		_superPopover.Constructor.prototype[args.shift()].apply(this, args);
	},
	show: function ()	{
		var	e =	$.Event('show.bs.' + this.type);

		if (this.hasContent() && this.enabled) {
			this.$element.trigger(e);

			if (e.isDefaultPrevented()) return
			var that = this;

			var $tip = this.tip();

			this.setContent();

			if (this.options.animation) $tip.addClass('fade');

			var placement	= typeof this.options.placement	== 'function' ?
				this.options.placement.call(this, $tip[0], this.$element[0]) :
				this.options.placement;

			var autoToken	= /\s?auto?\s?/i;
			var autoPlace	= autoToken.test(placement);
			if (autoPlace) placement = placement.replace(autoToken, '') || 'top';

			$tip
				.detach()
				.css({ top:	0, left: 0,	display: 'block' })
				.addClass(placement);
			
			if (typeof(this.options.cssClass) != 'undefined') {
				$tip.addClass(this.options.cssClass);
			}	
			if (typeof(this.options.maxWidth) != 'undefined') {
				$tip.css( { 'max-width': this.options.maxWidth} );
			}
			if (typeof(this.options.maxHeight) != 'undefined') {
				$tip.css({
					'max-height': this.options.maxHeight,
					'overflow': 'hidden'
				});
			}

			// (Commentaire pour la maintenance) Les lignes suivantes remplacent :
			this.tipIso = $("<div class='isolation-bootstrap-3'></div>");
			$tip.appendTo(this.tipIso);
			this.options.container ? this.tipIso.appendTo(this.options.container) : $tip.insertAfter(this.$element);
			// ... la ligne ci-dessous :
			//this.options.container ? $tip.appendTo(this.options.container) : $tip.insertAfter(this.$element);

			var pos		   = this.getPosition();
			var actualWidth  = $tip[0].offsetWidth;
			var actualHeight = $tip[0].offsetHeight;

			if (autoPlace) {
				var	$parent	= this.$element.parent();

				var	orgPlacement = placement;
				var	docScroll	 = document.documentElement.scrollTop || document.body.scrollTop;
				var	parentWidth	 = this.options.container == 'body'	? window.innerWidth	 : $parent.outerWidth();
				var	parentHeight = this.options.container == 'body'	? window.innerHeight : $parent.outerHeight();
				var	parentLeft	 = this.options.container == 'body'	? 0	: $parent.offset().left;

				placement =	placement == 'bottom' && pos.top   + pos.height	 + actualHeight	- docScroll	> parentHeight	? 'top'	   :
							placement == 'top'	  && pos.top   - docScroll	 - actualHeight	< 0							? 'bottom' :
							placement == 'right'  && pos.right + actualWidth > parentWidth								? 'left'   :
							placement == 'left'	  && pos.left  - actualWidth < parentLeft								? 'right'  :
							placement;

			$tip
				.removeClass(orgPlacement)
				.addClass(placement);
			}

			var calculatedOffset = this.getCalculatedOffset(placement, pos, actualWidth, actualHeight);

			this.applyPlacement(calculatedOffset,	placement);
			this.hoverState =	null;

			var complete = function()	{
				that.$element.trigger('shown.bs.' +	that.type);
			};

			$.support.transition && this.$tip.hasClass('fade') ?
			$tip
				.one($.support.transition.end, complete)
				.emulateTransitionEnd(150) :
			complete();
		}
	},
	getCalculatedOffset: function(placement, pos, actualWidth, actualHeight) {
		this.arrowBackgroundPosition = 0;
		this.arrowWidth = 0;

		switch (placement) {
			case 'bottom':
				if (this.options["arrow"] == "right") {
					tp = {top: pos.top + pos.height, left: pos.left + pos.width / 2 - actualWidth + 35};
					this.arrowBackgroundPosition = actualWidth - 34;
				}
				else if (this.options["arrow"] == "left") {
					tp = {top: pos.top + pos.height, left: pos.left + pos.width / 2 - 35};
					this.arrowBackgroundPosition = 34;
				}
				else {
					tp = {top: pos.top + pos.height, left: pos.left + pos.width / 2 - actualWidth / 2};
					this.arrowBackgroundPosition = actualWidth / 2;
				}

				this.arrowWidth = actualWidth;
				break;
			case 'top':
				if (this.options["arrow"] == "right") {
					tp = {top: pos.top - actualHeight, left: pos.left + pos.width / 2 - actualWidth + 35};
					this.arrowBackgroundPosition = actualWidth - 34;
				}
				else if (this.options["arrow"] == "left") {
					tp = {top: pos.top - actualHeight, left: pos.left + pos.width / 2 - 35};
					this.arrowBackgroundPosition = 34;
				}
				else {
					tp = {top: pos.top - actualHeight, left: pos.left + pos.width / 2 - actualWidth / 2};
					this.arrowBackgroundPosition = actualWidth / 2;
				}

				this.arrowWidth = actualWidth;
				break;
			case 'left':
				tp = {top: pos.top + pos.height / 2 - actualHeight / 2, left: pos.left - actualWidth};
				break;
			case 'right':
				tp = {top: pos.top + pos.height / 2 - actualHeight / 2, left: pos.left + pos.width};
				break;
		}

		var $tip = this.tip();
		$tip.on('click', '[data-dismiss="clickover"]', $.proxy(this.hideViaFermer, this));
      	calculatedOffset = tp;

      	return calculatedOffset;
	},
	replaceArrow: function() {
		//this.arrow().css(position, delta ? (50 * (1 - delta / dimension) + "%") : '')
		if (this.options.arrow == 'left'){
			this.arrow().css("background-position", this.arrowBackgroundPosition + "px 0");
			this.arrow().css("left", "0");
		}
		else if (this.arrowBackgroundPosition != 0) {
			this.arrow().css("background-position", this.arrowBackgroundPosition + "px 0");
			this.arrow().css("width", this.arrowWidth + "px");
			this.arrow().css("left", "0");
		}
	},
	hideViaFermer: function() {
		this.leave(this);
		this.tipIso.remove();
		return false;
	}
});

$.fn.popover = $.extend(function(option) {

	var args = $.makeArray(arguments),
		option = args.shift();

	return this.each(function() {

		var $this = $(this);
		var data = $this.data('bs.popover'),
			options = $.extend({}, _superPopover.defaults, $this.data(), typeof option == 'object' && option);

		if ( !data ) $this.data('bs.popover', (data = new Popover(this, options)));

		if (typeof option == 'string') {
			data[option].apply( data, args );
		}
		else if ( options.show ) {
			data.show.apply( data, args );
		}

		if(options.onlyOne) {
			$('body').on('click', function (e) {
				$('[data-toggle="popover"], [data-toggle="datepicker"]').each(function () {
					//the 'is' for buttons that trigger popups
					//the 'has' for icons within a button that triggers a popup
					if (!$(this).is(e.target) && $(this).has(e.target).length === 0 && $('.popover').has(e.target).length === 0) {
						$(this).popover('hide');
					}
				});
			});
		}
	});

}, $.fn.popover);

/** Affichage de la grille d'alignement */
function toggleGridCanvas() {
	var container = $('#row-grid-alignement');
	var columns = $("#row-grid-alignement .col-xs-1");
	var columnsInner = $("div", columns);
	var documentHeight = $(document).height();

	if (!container.hasClass('visible')) {
		container.addClass('visible');
		columns.css({
			'height': documentHeight,
			'z-index': '9000'
		});
		columnsInner.css('height', documentHeight);
	}
	else {
		container.removeClass('visible');
		columns.css({
			'height': '0',
			'z-index': '0'
		});
		columnsInner.css('height', '0');
	}
}

function afficherGridAlignement() {
	// Trouve le nombre de colonne
	var body = $('body');
	body.prepend('<div style="display:none" id="check-container-nb-col" class="container"><div id="check-row-nb-col" class="row"><div id="check-md-1" class="col-md-1"></div></div></div>');
	var nbColonne = 1;
	while ( $("#check-md-" + nbColonne).css("padding-left") != "0px" ) {
		nbColonne++;
		$('#check-row-nb-col').append('<div id="check-md-' + nbColonne + '" class="col-md-' + nbColonne + '"></div>');
	}
	$('#check-container-nb-col').remove();
	nbColonne -= 1;

	var gridboxs = "";
	for ( var i = 1; i <= nbColonne; i++ ) {
		gridboxs += '<div class="col-xs-1 col-md-1" style="position: absolute;"><div style="filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#19FF0000, endColorstr=#19FF0000); background-color: rgba(255, 0, 0, 0.06); border-radius: 3px; line-height: 40px; min-height: 40px; text-align: center; cursor: pointer;">' + i + '</div></div>';
	}
	var gridLine = '<div class="container"><div id="row-grid-alignement" class="row show-grid" style="position: relative; height: 40px;" onclick="toggleGridCanvas()">' + gridboxs + '</div></div>';

	body.prepend(gridLine);

	var gutter = $("#row-grid-alignement .col-xs-1").first().css("padding-left").replace(/[^-\d\.]/g, '') * 2;

	var widthGrid = $('.container').width();
	var widthColumn = (widthGrid - (gutter * (nbColonne - 1))) / nbColonne;

	var col = 1;
	for (var x=0; x < widthGrid ; x+=(widthColumn+gutter)) {
		$("#row-grid-alignement .col-xs-1:nth-child(" + col + ")").css('left', x);
		col++;
	}
}

/*
 * Menu
 * -------------------------------------------------- */
 (function($) {

	$.fn.menu = function(options) {
		var defaults = {
			animated: false,
			extended: false
        };

		var settings = $.extend(defaults, options);

		return this.each(function() {
			var navbar = $(this);
			var menu =$(".nav", navbar);

			var menuWidth = Math.round($(".dropdown", menu).length * 14.2 * 100) / 100;
			//menu.css("min-width", menuWidth + "rem");

			if(navbar.hasClass('menu-panneaux')) {
				var subMenuWidth = (menuWidth - 0.2) + 'rem';
				$(".dropdown-menu", menu).css('minWidth', subMenuWidth);

				$(".dropdown", menu).each(function(i, el) {
					$(".dropdown-menu", $(this)).css("left", "-" + Math.round(i * 14.2 * 100) / 100 + "rem");
				});

				// Remove top right radius if menu width = submenu width
				var dropdownMenuWidth = $(".dropdown:last-child .dropdown-menu", menu).css('width');
				if((menuWidth * 10 - 2) + 'px' == dropdownMenuWidth) {
					$(".dropdown:last-child .dropdown-menu", menu).css('border-radius', '4px 0 4px 4px');
				}
			}

			// ADD SLIDEDOWN ANIMATION TO DROPDOWN
			$('.dropdown', menu).on('show.bs.dropdown', function(e) {
				var dropdown = $(this);
				var dropdownToggle = dropdown.find('.dropdown-toggle');
				var dropdownMenu = dropdown.find('.dropdown-menu').first();
				dropdown.css("z-index", 52);
				dropdownToggle.css("z-index", 52);
				if(navbar.hasClass('animated')) {
					dropdownMenu.stop(true, true).slideDown("normal", function(e) {
					});
				}
				else {
					$('.nav .dropdown .dropdown-menu').not(dropdown).hide();
					dropdownMenu.show();
				}
			});

			// ADD SLIDEUP ANIMATION TO DROPDOWN
			$('.dropdown', menu).on('hide.bs.dropdown', function(e){
				var dropdown = $(this);
				var dropdownToggle = dropdown.find('.dropdown-toggle');
				var dropdownMenu = dropdown.find('.dropdown-menu').first();
				dropdown.css("z-index", 51);
				dropdownToggle.css("z-index", 51);
				if(navbar.hasClass('animated')) {
					dropdownMenu.stop(true, true).slideUp("normal", function(e) {

					});
				}
				else {
					dropdownMenu.hide();
				}
			});


			// Prevent dropdown to close while clicking its content
			$(".nav .dropdown-menu").on("click", function(e) {
				e.stopPropagation();
			})

			$(".nav .closeBtn").on('click', function(e) {
				e.preventDefault();
			$(this).parents(".open").find(".dropdown-toggle").dropdown("toggle");
			});

			if($.isFunction( settings.onComplete )) {
				settings.onComplete.call(this);
			}
		})
	}
})(jQuery);

/* INITIALISATION DU MENU */
$(function() {
	$(".menu-simple, .menu-panneaux").menu();
});



/*
 * Carousel
 * -------------------------------------------------- */
(function($) {

    // here we go!
    $.fwdCarousel = function(element, options) {
        // plugin's default options
        // these are private properties and are accessible only from inside the plugin
        var defaults = {
            items: 3,
			slideBy: 3,
			dots: false,
			mouseDrag: false,
			nav: true,
			navText: ['<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAPCAYAAADZCo4zAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkE3NEQxRDlBODNFMjExRTE5QzFFQjQ5RDA3MDZGNUUxIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkE3NEQxRDlCODNFMjExRTE5QzFFQjQ5RDA3MDZGNUUxIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6QTc0RDFEOTg4M0UyMTFFMTlDMUVCNDlEMDcwNkY1RTEiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6QTc0RDFEOTk4M0UyMTFFMTlDMUVCNDlEMDcwNkY1RTEiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz5jP8AIAAAA5klEQVR42mL8//8/AzqIiooSA1LiQPyUBYukFpAqBWJFIJ7OgiapBqRagTgAKrSFCUlSFUh1IkluAOLNTFBJJSDVgSZZtmzZspvMt27dUoNKBgPxX6hkDUgSpBLkhi4g9gPib1DJVqDkNZjVICt8gJgRiF8AcTeyJEzBDSgb5I5EoHtE0BWUAfFZKD8XiAuAivhhChhBIQkUsAeypwGxFtQtS4E4H2jdd0ZYUAMVeQCpBiA2h2oGBdhkRuS4ACryAjkUatJvIG5nQouKXUBcCHXTH5AbGdFjE2iKAJCKBGJRIF4PEGAAwpdLMa0eC/QAAAAASUVORK5CYII=" alt="afficher les images précédentes">', '<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAPCAYAAADZCo4zAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjkyMEU4MjY4ODNFMjExRTE4QjNGODBDNzA0QjQ3QUFCIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjkyMEU4MjY5ODNFMjExRTE4QjNGODBDNzA0QjQ3QUFCIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6OTIwRTgyNjY4M0UyMTFFMThCM0Y4MEM3MDRCNDdBQUIiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6OTIwRTgyNjc4M0UyMTFFMThCM0Y4MEM3MDRCNDdBQUIiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz6u/HNBAAAA6ElEQVR42mKMjIwUYmBgkAbil8uWLXvFgAaYgNgViCcDcWdUVJQWNgWyQGwPxAlA3ApUpIauYDMQb4DyA6AmqcIVAO29CaTL0BR1ABUpgTiM////B4tC7W8GYn8gZgbitUBcBVeApKgaagonEG9CUQBVZADVDbLiLxOapAiQSoRKgsANJiRJfiBVAMS5UKGzIMeDrQBKguybCMTRQMwFxNeAOAvow4PMt27dEgdySqC6WYH4JMj1QMm9sIDKgoYDA1RnE1ByB3JIgvAfqJ2FQLwL2eEsQLwKiH8D8WsgPgXU/QdZAUCAAQAAh0nagB6U2QAAAABJRU5ErkJggg==" alt="afficher les images suivantes">'],
			margin: 10,
			navRewind: false,
			autoplay: false,
			autoplayTimeout: 5000,
			themeClass: 'owl-theme',

            // if your plugin is event-driven, you may provide callback capabilities for its events.
            // execute these functions before or after events of your plugin, so that users may customize
            // those particular events without changing the plugin's code
            onItemSelected: false
        }

        // to avoid confusions, use "plugin" to reference the current instance of the object
        var plugin = this;

        // this will hold the merged default, and user-provided options
        // plugin's properties will be available through this object like:
        // plugin.settings.propertyName from inside the plugin or
        // element.data('carousel').settings.propertyName from outside the plugin, where "element" is the element the plugin is attached to;
        plugin.settings = {}

        var $element = $(element),  // reference to the jQuery version of DOM element the plugin is attached to
             element = element;        // reference to the actual DOM element

        // the "constructor" method that gets called when the object is created
        plugin.init = function() {
            // the plugin's final properties are the merged default and user-provided options (if any)
            plugin.settings = $.extend({}, defaults, options);

            $element.addClass(plugin.settings.themeClass);

            $element.on('initialized.owl.carousel', defaultInitListeners)
            .on('changed.owl.carousel', defaultInitListeners)
            .on('refreshed.owl.carousel', defaultInitListeners)
            .on('refreshed.owl.carousel', userInitListeners)
            .owlCarousel({
				items: plugin.settings.items,
				slideBy: plugin.settings.slideBy,
				dots: plugin.settings.dots,
				mouseDrag: plugin.settings.mouseDrag,
				nav: plugin.settings.nav,
				navText: plugin.settings.navText,
				margin: plugin.settings.margin,
				navRewind: plugin.settings.navRewind,
				autoplay: plugin.settings.autoplay,
				autoplayTimeout: plugin.settings.autoplayTimeout
			})
        }

        /**
         * public methods
         */

        // add an item
        plugin.add = function(item) {
        	var $item = $('<div>', {
				'class': 'item'
			});
			var $img = $('<img />', {
				'src': item.src,
				'alt': item.alt
			});
			$div.append($img);       	
			var owl = $element.data('owl.carousel');

        	owl.add($item);
    		owl.refresh();
        }

        // Replace content
        plugin.replace = function(content) {
			var owl = $element.data('owl.carousel');
        	var newContent = '';
        	$.each(content, function(i, image) {
				newContent += '<div class="item"><img src="' + image.src + '" alt="' + image.alt + '" tabindex="' + image.tabIndex + '" /></div>';
        	})
    		owl.replace(newContent);
    		owl.refresh();
        }

        /**
         * private methods
         */

        var defaultInitListeners = function(event) {
            var carousel = event.relatedTarget,
			element = event.target,
			current = carousel.current();
			$('.owl-next', element).toggleClass('disabled', current === carousel.maximum());
			$('.owl-prev', element).toggleClass('disabled', current === carousel.minimum());

			var items = $('.item', event.target);
			items.on('click.default tap.default', function(e) {
				items.not($(this)).parent().removeClass('selected');
				$(this).parent().addClass('selected');
			});
        }

        var userInitListeners = function(event) {
			if($.isFunction(plugin.settings.onItemSelected)) {
				var items = $('.item', event.target);
				items.off('click.user tap.user');
				items.on('click.user tap.user', plugin.settings.onItemSelected);
			}
        }

        // fire up the plugin!
        // call the "constructor" method
        plugin.init();

    }

    // add the plugin to the jQuery.fn object
    $.fn.fwdCarousel = function(options) {
        // iterate through the DOM elements we are attaching the plugin to
        return this.each(function() {
            // if plugin has not already been attached to the element
            if (undefined == $(this).data('fwdCarousel')) {
                // create a new instance of the plugin
                // pass the DOM element and the user-provided options as arguments
                var plugin = new $.fwdCarousel(this, options);

                // in the jQuery version of the element
                // store a reference to the plugin object
                // you can later access the plugin and its methods and properties like
                // element.data('fwdCarousel').publicMethod(arg1, arg2, ... argn) or
                // element.data('fwdCarousel').settings.propertyName
                $(this).data('fwdCarousel', plugin);
            }
        });
    }

})(jQuery);


/*
 * Datepicker
 * -------------------------------------------------- */
(function($) {
	if (typeof dhtmlXCalendarObject != 'undefined') {
		dhtmlXCalendarObject.prototype.langData["en"] = {
		    dateformat: '%Y-%m-%d',
		    monthesFNames: ["January","February","March","April","May","June","July","August","September","October","November","December"],
		    monthesSNames: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],
		    daysFNames: ["Sunday", "Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"],
		    daysSNames: ["Sun", "Mon","Tue","Wed","Thu","Fri","Sat"],
		    weekstart: 1,
		        weekname: "w" 
		};

	 	dhtmlXCalendarObject.prototype.langData["fr"] = {
		    dateformat: '%Y-%m-%d',
		    monthesFNames: ["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"],
		    monthesSNames: ["JAN","FÉV","MAR","AVR","MAI","JUN","JUI","AOU","SEP","OCT","NOV","DÉC"],
		    daysFNames: ["Dimanche", "Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi"],
		    daysSNames: ["DIM", "LUN","MAR","MER","JEU","VEN","SAM"],
		    weekstart: 1,
		        weekname: "w" 
		};

	    // here we go!
	    $.fwdDatepicker = function(options) {

	        var defaults = {
	        	popover: {
					trigger: false,
			        placement: 'bottom',
			        onlyOne: true,
			        arrow: false
				},
			    datepicker: {
			    	container: false,
					//timepicker: false,
			        disableDays: false,
			        setInsensitiveDays: false,
			        setInsensitiveRange: false,
			        setWeekStartDay: false,
			        lang: false,
			        onClick: false
			    },
			    fields: {
			    	month: {
			    		autoPopulate: true
			    	}
			    }
	        }

	        // the "constructor" method that gets called when the object is created
	        init = function(options) {
	        	if(typeof options.type === 'undefined') {
	        		options.type = 'popover';
			        var settings = $.extend(true, defaults, options);
		        	
			    }
			    else if(typeof options.type === 'string') {
			        var settings = $.extend(true, defaults, options);
			        delete settings.popover;
			    }

			    if(typeof options.datepicker.lang != 'undefined') {
	        		settings.datepicker.lang = options.datepicker.lang;
	        	}
		        var calendar = initCalendar(options.type, settings);
		        return calendar;
	        }

	        // fire up the plugin!
	        // call the "constructor" method
	        var dhtmlxCalendarInstance = init(options);
	        return {
	        	plugin: this,
	        	datepicker: dhtmlxCalendarInstance
	        };

	    }

	    // add the plugin to the jQuery.fn object
	    $.fn.fwdDatepicker = function(options) {
	        var elementId = this.attr('id');
	        // iterate through the DOM elements we are attaching the plugin to
	        return this.each(function() {
	            // if plugin has not already been attached to the element
	            if (undefined == $(this).data('fwdDatepicker')) {
	                // create a new instance of the plugin
	                // pass the DOM element and the user-provided options as arguments
	                var fullOptions = {
	                	type: 'inline',
	                	datepicker: options
	                }
	                fullOptions.datepicker.container = elementId;
	                var plugin = new $.fwdDatepicker(fullOptions);

	                // in the jQuery version of the element
	                // store a reference to the plugin object
	                // you can later access the plugin and its methods and properties like
	                // element.data('fwdDatepicker').publicMethod(arg1, arg2, ... argn) or
	                // element.data('fwdDatepicker').settings.propertyName
	                $(this).data('fwdDatepicker', plugin);
	            }
	        });
	    }

	    function initCalendar(type, options) {
	    	if(type == 'popover') {
	    		options.datepicker.container = 'fwdPopoverDatepicker';
	    		if(options.datepicker.lang == false) {
		    		options.datepicker.lang = $('html').is('[lang]') ? $('html').attr('lang').substring(0, 2) : 'fr';
		    	}

	    		// Helper pour peupler automatiquement une liste déroulante avec les mois de l'année en fonction de la langue
	    		if(options.fields.month.autoPopulate) {
	    			var fieldset = $(options.popover.trigger).closest('fieldset');
					var month = $('.month', fieldset);
					month.html('');
					$.each(dhtmlXCalendarObject.prototype.langData[options.datepicker.lang].monthesSNames, function(i, name) {
						month.append('<option value="' + padNumber(i+1, 2) + '">' + name + '</option>');
					})
	    		}

				var selector = $(options.popover.trigger);

				selector.attr('data-toggle', 'datepicker');

	            selector.popover({
					content: function() {
						return '<div id="' + options.datepicker.container + '" style="position: relative; width: 256px; height: 275px;"></div>';
					},
					html: true,
					animation: false,
					onlyOne: options.popover.onlyOne,
					placement: options.popover.placement,
					arrow: options.popover.arrow
				})
				.on('shown.bs.popover', function () {
	            	var calendar = instantiateCalendar(options);

	            	calendar.attachEvent("onShow", function() {
						calendarPopoverShow(this, options);
					});

					calendar.attachEvent("onClick", function(date) {
						calendarPopoverClick(this, options);
						if(options.datepicker.onClick && $.isFunction(options.datepicker.onClick)) {
							options.datepicker.onClick(this.getFormatedDate());
						}
					});

					calendar.show();
					return calendar;
	            })
	        }
			else if(type == 'inline') {
				$('#' + options.datepicker.container).css({
					width: '258px',
					height: '273px',
					position: 'relative'
				});

				var calendar = instantiateCalendar(options);

				calendar.attachEvent("onShow", function() {
					calendarShow(this);
				});

				calendar.attachEvent("onClick", function(date) {
					//calendarClick(this);
					if(options.datepicker.onClick && $.isFunction(options.datepicker.onClick)) {
						options.datepicker.onClick(this.getFormatedDate());
					}
				});

				calendar.show();
				return calendar;
			}
	    }

	    function instantiateCalendar(options) {
	    	var calendar = new dhtmlXCalendarObject(options.datepicker.container);
	    	
			calendar.loadUserLanguage(options.datepicker.lang);

			if(!options.datepicker.timepicker) {
				calendar.hideTime();
			}

			if(options.datepicker.setWeekStartDay) {
				calendar.setWeekStartDay(options.datepicker.setWeekStartDay);
			}

			if(options.datepicker.disableDays) {
				if($.isArray(options.datepicker.disableDays) && options.datepicker.disableDays.length)
				for(var prop in options.datepicker.disableDays) {
					for(var objectProp in options.datepicker.disableDays[prop]) {
						calendar.disableDays(objectProp, options.datepicker.disableDays[prop][objectProp]);
					}
				}
			}

			if(options.datepicker.setInsensitiveDays) {
				calendar.setInsensitiveDays(options.datepicker.setInsensitiveDays);
			}

			if(options.datepicker.setInsensitiveRange) {
				var from = options.datepicker.setInsensitiveRange[0];
				var to = options.datepicker.setInsensitiveRange[1];
				calendar.setInsensitiveRange(from, to);
			}

			return calendar;
	    }

	    // Popover mode
	    function calendarPopoverClick(dhtmlxCalendarInstance, options) {
	    	var formatedDate = dhtmlxCalendarInstance.getFormatedDate();
			var fieldset = $(options.popover.trigger).closest('fieldset');
			var day = $('.day', fieldset);
			var month = $('.month', fieldset);
			var year = $('.year', fieldset);
			day.val(parseInt(formatedDate.substring(8, 10), 10));
			$('option[value="' + formatedDate.substring(5, 7) + '"]', month).prop('selected', true);
			year.val(formatedDate.substring(0, 4));
	    }

	    function calendarPopoverShow(dhtmlxCalendarInstance, options) {
			var fieldset = $(options.popover.trigger).closest('fieldset');
			var day = $('.day', fieldset);
			var month = $('.month', fieldset);
			var year = $('.year', fieldset);

			day = day.val();
			month = $('option:selected', month).val();
			year = year.val();
			var now = new Date();
			month = day != '' ? month : parseInt(now.getMonth() + 1, 10);
			day = day != '' ? day : now.getDate().toString();
			year = year != '' ? year : now.getFullYear();
			dhtmlxCalendarInstance.setDate(year + '-' + month + '-' + padNumber(day, 1));
	    }

	    // Inline mode
	    /*function calendarClick(dhtmlxCalendarInstance) {

	    }*/

	    function calendarShow(dhtmlxCalendarInstance) {
			var now = new Date();
			var day = now.getDate() + 1;
			var month = parseInt(now.getMonth() + 1);
			var year = now.getFullYear();
			dhtmlxCalendarInstance.setDate(year + '-' + month + '-' + day);
	    }
	}

})(jQuery);



/*
 * TreeGrid
 * -------------------------------------------------- */
function enhanceTreeGrids() {
	var grids = $('.gridbox');
	$.each(grids, function(id, value) {
		var currentGrid = $(value).get(0).grid;
		dhtmlxEvent( currentGrid.obj, "click", function(ev){
			var el = ev.target || ev.srcElement;
			if (el.id == "nodeval"){
					var id = currentGrid.getFirstParentOfType(el, "TR").idd;
				if(currentGrid.getOpenState(id)) {
					currentGrid.closeItem(id);
				}
				else {
					currentGrid.openItem(id);
				}
			}
		});
	})
}



/**
 * VALIDATION DE FORMULAIRE CÔTÉ CLIENT
 */
// Réglages par défaut
$(function() {
	if($.validator) {
		$.validator.setDefaults({
	        onfocusout: false,
	        focusInvalid: false,
	        errorElement: 'span',   
			errorPlacement: function(error, element) {
	        	var elType = element.get(0).type;

	        	if(elType == 'checkbox' || elType == 'radio') {
	        		error.insertBefore(element.closest('.' + elType)).addClass('help-block');
	        	}
	        	else {
	        		error.insertBefore(element).addClass('help-block');
	        	}
	        },
	        highlight: function(element, errorClass) {
				$(element).closest('.form-group').addClass('has-error');
			},
	        unhighlight: function(element, errorClass) {
				$(element).closest('.form-group').removeClass('has-error');
			},
		});
	}
});



/**
 * Open new window (popup)
 */
function openPopup(url, width, height) {
	var myWindow = window.open(url, "", "width=" + width + ", height=" + height + "");
}


/**
 * Misc.
 */
 // Add leading 0 to numbers less than 10
function padNumber(number, pad) {
  var n = Math.pow(10, pad);
  return number < n ? ("" + (n + number)).slice(1) : "" + number
}