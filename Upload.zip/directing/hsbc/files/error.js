define({
	root: {
		LOG_0002_01: "The username you entered does not match our records. Please try again.",	
		LOG_0002_02: "The username you entered does not match our records. Please try again.",
		LOG_0006_01_1: "The information you entered does not match our records. You have ",
		LOG_0006_01_2: " attempt(s) left, please try again.",		
		LOG_PASSWORD_ENTER_DOB:"The information you entered does not match our records. Please enter your date of birth and password to continue.",
		LOG_INVALID_USER_SECURE_1:"The information you entered does not match our records. You have ",
		LOG_INVALID_USER_SECURE_2:" attempt[s] remaining, please try again.",
		LOG_SECURE_KEY_ENTER_DOB:"The information you entered does not match our records. Please enter your date of birth and security code to continue.",
		LOGON_DOB_GREATER_MESSAGE:"Date of birth must be in the past",
		LOGON_DOB_DAY_GREATER_MESSAGE:"The day must be a two-digit number between 01 and ",
		LOG_SEC_CODE_LOW_BATT : "Low Battery. Please use Password to Login"
	}
});